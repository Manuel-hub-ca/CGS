//
//  Artist.h
//  CGS
//
//  Created by Mac on 2022-10-06.
//

#import <Foundation/Foundation.h>
#import "Person.h"
NS_ASSUME_NONNULL_BEGIN

@interface Artist : Person{
    NSString *ArtistID;    
}
-(id) initArtistID:(NSString *)AId initfirstName:(NSString *)FN initlastName:(NSString *)LN;
-(NSString *) getArtistID;
-(NSString *) toString;
@end

NS_ASSUME_NONNULL_END
