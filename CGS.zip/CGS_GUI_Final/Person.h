//
//  Person.h
//  CGS
//
//  Created by Mac on 2022-10-05.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject{
    NSString *firstname;
    NSString *lastname;

}
-(id) initFirstName:(NSString *)FN initLastName:(NSString *)LN;
-(NSString *) toString;
-(NSString *) getlasttname;
-(NSString *) getfirstname;
-(void) setfirstName:(NSString *) fn;
-(void) setlastName:(NSString *) ln;
@end

NS_ASSUME_NONNULL_END   		
