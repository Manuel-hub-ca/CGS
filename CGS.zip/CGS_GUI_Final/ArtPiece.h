//
//  ArtPiece.h
//  CGS
//
//  Created by Mac on 2022-10-12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ArtPiece : NSObject{
    NSString *artPieceId;
    NSString *curatorId;
    NSString *artistId;
    NSString *Title;
    int year;
    float value;
    float estimate;
    char status;
    
}
-(id) initiartPieceId:(NSString *)artPI initicuratorId:(NSString *)cId initartistId:(NSString *)artId initTitle:(NSString *)Tit inityear:(int)y initvalue:(float)val initestimate:(float)estim initstatus:(char)stat;
-(NSString *) toString;
-(NSString *) getpieceId;
-(float) getValue;
-(void) changeStatus:(char)status;
-(NSString *) getCuratorId;
-(void)setEstimate:(float)esti;
@end

NS_ASSUME_NONNULL_END
