//
//  ViewController.h
//  CGS_GUI_Final
//
//  Created by Mac on 2022-11-14.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

-(BOOL)verifyCuratorId:(NSString *)curatorId;
-(BOOL)VerifyArtistId:(NSString *)artistId;
-(BOOL)verifyArtPieceId:(NSString *)artPieceId;
-(BOOL)sellingArtPiece:(NSString *)artPieceId :(float)value;
@end

