//
//  SceneDelegate.h
//  CGS_GUI_Final
//
//  Created by Mac on 2022-11-14.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

