//
//  ViewController.m
//  CGS_GUI_Final
//
//  Created by Mac on 2022-11-14.
//

#import "ViewController.h"
#import "Curator.h"
#import "Artist.h"
#import "ArtPiece.h"
Curator *myCurators[10];
Artist *myArtists[10];
ArtPiece *myArtPieces[10];
int sizeMyCurators = sizeof(myCurators)/ sizeof(myCurators[0]);
int sizeMyArtists = sizeof(myArtists)/ sizeof(myArtists[0]);
int sizeMyArtPieces = sizeof(myArtPieces)/ sizeof(myArtPieces[0]);
int indexCuratos = 0;
int indexArtists = 0;
int indexMyArtPieces = 0;


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *Username;
@property (weak, nonatomic) IBOutlet UITextField *Password;
@property (weak, nonatomic) IBOutlet UITextField *curatorIDTextBox;
@property (weak, nonatomic) IBOutlet UITextField *curFirstname;
@property (weak, nonatomic) IBOutlet UITextField *curLastname;
@property (weak, nonatomic) IBOutlet UITextField *artistId;
@property (weak, nonatomic) IBOutlet UITextField *artistFirstname;
@property (weak, nonatomic) IBOutlet UITextField *artistLastname;
@property (weak, nonatomic) IBOutlet UITextField *artPieceId;
@property (weak, nonatomic) IBOutlet UITextField *artPieceCId;
@property (weak, nonatomic) IBOutlet UITextField *ArtPieceAId;
@property (weak, nonatomic) IBOutlet UITextField *tile;
@property (weak, nonatomic) IBOutlet UITextField *year;
@property (weak, nonatomic) IBOutlet UITextField *value;
@property (weak, nonatomic) IBOutlet UITextField *sellArtPiece;
@property (weak, nonatomic) IBOutlet UITextField *estimate;

@end


@implementation ViewController

-(BOOL)verifyCuratorId:(NSString *)curatorId{
    BOOL flag = false;
    for(int i =0; i < indexCuratos; i++){
        if([myCurators[i] getID] == curatorId){
            flag = true;
        }
    }
    return flag;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)LoginButton:(id)sender {
    NSString* username = [_Username text];
    NSString* password = [_Password text];
    
    if ([username isEqualToString:@"admin"] && [password isEqualToString:@"123"]){
        //code here
        ViewController *monitorMenuViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MainForm"];
        [self presentViewController:monitorMenuViewController animated:NO completion:nil];
    }
   else{
       UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Error" message:@"Credentials are incorrect" preferredStyle:UIAlertControllerStyleAlert];

            UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

            handler:^(UIAlertAction * action) {}];
            [alert addAction:defaultAction];

            [self presentViewController:alert animated:YES completion:nil];
    }
}



- (IBAction)addCuratorBtn:(id)sender {
    NSString *message = @"";
    NSString *curtorID = [_curatorIDTextBox text];
    NSString *curFirstname = [_curFirstname text];
    NSString *curLastname = [_curLastname text];
    
    if ([curtorID length] != 5){
        message = @"Error! CuratorID should be 5 chars!";
    }
    else{
        // 1. write a method to check the existence of the ID
        
        if ([self verifyCuratorId:curtorID]){
            message = @"This ID already exists!";
        }
        else{
            if ([curLastname length] + [curLastname length] > 40){
                message = @"The last name and lastname exceed the 40 characters";
            }
            else{
                Curator *newCurator = [[Curator alloc]initCuratorId:curtorID initFirstName:curFirstname initLastName:curLastname initCommission:0.0];
                myCurators[indexCuratos] = newCurator;
                indexCuratos++;
                message = @"Curator added succesfully!";
            }
        }
    }
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Attention" message:message preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
    if([message isEqual:@"Curator added succesfully!"]){
        [_curatorIDTextBox setText:@""];
        [_curFirstname setText:@""];
        [_curLastname setText:@""];

    }
}

-(BOOL)VerifyArtistId:(NSString *)artistId{
    BOOL flag = false;
    for (int i = 0; i < indexArtists; i++) {
        if([myArtists[i] getArtistID] == artistId){
            flag = true;
        }
    }
    return flag;
}

- (IBAction)addArtistBtn:(id)sender {
    NSString *msg = @"";
    NSString *artistId = [_artistId text];
    NSString *artistFirstname = [_artistFirstname text];
    NSString * artistLastname = [_artistLastname text];
    
    if([artistId length] != 5){
        msg = @"Error! ArtistId should be 5 chars!";
    }else{
        if([self VerifyArtistId:artistId]){
            msg = @"This ID already exists!";
        }
        else{
            if([artistFirstname length] + [artistLastname length] > 40){
                msg = @"The last name and lastname exceed the 40 characters";
            }
            else{
                Artist *newArtist = [[Artist alloc] initArtistID:artistId initfirstName:artistFirstname initlastName:artistLastname];
                myArtists[indexArtists] = newArtist;
                indexArtists++;
                msg = @"Artist added successfully!";
            }

        }
    }
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Attention" message:msg preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
    if([msg isEqual:@"Artist added successfully"]){
        [_artistId setText:@""];
        [_artistFirstname setText:@""];
        [_artistLastname setText:@""];
    }

}

-(BOOL)verifyArtPieceId:(NSString *)artPieceId{
    BOOL flag = false;
    for (int i = 0; i < indexMyArtPieces; i++) {
        if([myArtPieces[i] getpieceId] == artPieceId){
            flag = true;
        }
    }
    return flag;
}

- (IBAction)addArtPiece:(id)sender {
    NSString *msg =@"";
    NSString *artPieceId = [_artPieceId text];
    NSString *curatorId = [_artPieceCId text];
    NSString *artistId  = [_ArtPieceAId text];
    NSString *title = [_tile text];
    NSString *year = [_year text];
    int y = [year intValue];
    NSString *value = [_value text];
    float v = [value floatValue];
    
    if([artPieceId length] != 5){
        msg = @"Error! ArtPieceId should be 5 chars!";
    }else{
        if([self verifyArtPieceId:artPieceId]){
            msg = @"This ID already exists!";
        }else{
            if([self verifyCuratorId:curatorId] == false){
                msg=@"This curator does not exist!";
            }else{
                if([self VerifyArtistId:artistId] == false){
                    msg = @"This Artist does not exist!";
                }else{
                    if([year length] != 4){
                        msg = @"The year's field should be composed by not more than 4 digits!";
                    }
                    else if (y > 2022){
                        msg = @"Impossible to fill the year's field with a future date!";
                    }
                    else{
                        ArtPiece *newArtPiece = [[ArtPiece alloc]initiartPieceId:artPieceId initicuratorId:curatorId initartistId:artistId initTitle:title inityear:y initvalue:v initestimate:0.0 initstatus:'D'];
                        myArtPieces[indexMyArtPieces] = newArtPiece;
                        indexMyArtPieces++;
                        msg = @"Art Piece added successfully!";
                    }

                }
            }
        }
    }
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Attention" message:msg preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
    if([msg isEqual:@"Art Piece added successfully!"]){
        [_artPieceId setText:@""];
        [_artPieceCId setText:@""];
        [_ArtPieceAId setText:@""];
        [_tile setText:@""];
        [_year setText:@""];
        [_value setText:@""];
    }


}
-(BOOL)sellingArtPiece:(NSString *)artPieceId :(float)estimate{
    for(int i = 0; i < indexMyArtPieces; i++){
        if([myArtPieces[i] getpieceId] == artPieceId){
            int value = [myArtPieces[i] getValue];
            if(value < estimate){
                [myArtPieces[i] changeStatus:'S'];
                [myArtPieces[i] setEstimate:estimate];
                float comm = (estimate - [myArtPieces[i] getValue]) * 0.25;
                NSString *cId = [myArtPieces[i] getCuratorId];
                for(int j = 0; i < indexCuratos; i++){
                    if([myCurators[j] getID] == cId){
                        [myCurators[j] setCommission:comm];
                    }
                }
                return true;
            }
        }
    }
    return false;
}

- (IBAction)SellArtPiece:(id)sender {
    NSString *artPieceId = [_sellArtPiece text];
    NSString *msg = @"";
    NSString *estimate = [_estimate text];
    float e = [estimate floatValue];
    if([self sellingArtPiece:artPieceId :e]){
        msg = @"Congratulation Art Picece Sold";
    }
    else{
        msg = @"Sorry,we decide not to sell this beatiful art piece for this amount of money, please try offerring another amount";
    }
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Attention" message:msg preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
    
    [_estimate setText:@""];
    [_sellArtPiece setText:@""];
}


- (IBAction)displayCuratorInf:(id)sender {
    NSString *infoOneCurator;
    NSString *info = @"";
    for(int i = 0; i < indexCuratos;i++){
        infoOneCurator = [myCurators[i] toString];
        info = [info stringByAppendingString:infoOneCurator];
        
    }
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Curators Info:" message:info preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
    
}
- (IBAction)DisplayArtistInfo:(id)sender {
    NSString *infoOneArtist;
    NSString *info = @"";
    for(int i = 0;i< indexArtists;i++){
        infoOneArtist = [myArtists[i] toString];
        info = [info stringByAppendingString:infoOneArtist];
    }
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Artists Info:" message:info preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
}
    
    
    
    
- (IBAction)DisplayArtPieceInfo:(id)sender {
    NSString *infoOneArtPiece;
    NSString *info = @"";
    
    for (int i = 0;i < indexMyArtPieces; i++) {
        infoOneArtPiece = [myArtPieces[i] toString];
        info =[info stringByAppendingString:infoOneArtPiece];
    }
    
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:@"Art Pieces Info:" message:info preferredStyle:UIAlertControllerStyleAlert];

         UIAlertAction* defaultAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault

         handler:^(UIAlertAction * action) {}];
         [alert addAction:defaultAction];

         [self presentViewController:alert animated:YES completion:nil];
}

@end
