//
//  Artist.m
//  CGS
//
//  Created by Mac on 2022-10-06.
//

#import "Artist.h"

@implementation Artist
    -(NSString *) getArtistID{
        return ArtistID;
    }
    -(id) initArtistID:(NSString *)AId initfirstName:(NSString *)FN initlastName:(NSString *)LN{
        ArtistID = AId;
        firstname = FN;
        lastname = LN;
        
        return self;
    }

-(NSString *) toString{
    return [NSString stringWithFormat:(@"\n%@%@\n %@%@%@%@\n"), @"Artist Id: ",ArtistID, @"Name: ", firstname, @" ", lastname];
}
@end
