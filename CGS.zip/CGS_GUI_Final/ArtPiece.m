//
//  ArtPiece.m
//  CGS
//
//  Created by Mac on 2022-10-12.
//

#import "ArtPiece.h"

@implementation ArtPiece

-(id) initiartPieceId:(NSString *)artPI initicuratorId:(NSString *)cId initartistId:(NSString *)artId initTitle:(NSString *)Tit inityear:(int)y initvalue:(float)val initestimate:(float)estimat initstatus:(char)stat{
    artPieceId = artPI;
    curatorId = cId;
    artistId = artId;
    Title = Tit;
    year = y;
    value = val;
    estimate = estimat;
    status = 'D';
    return self;
}

-(NSString *) toString{
    return [NSString stringWithFormat:(@"\n%@%@ \n%@ %@ \n%@ %@ \n%@ %@ \n%@ %i \n%@ %.2f \n%@ %.2f \n%@ %c\n"), @"Art Piece Id:",artPieceId, @"CuratorId: ", curatorId, @"Artist Id: ", artistId, @"Title: ", Title, @"Year: ", year,  @"Value: ", value, @"Estimate: ", estimate, @"Status: ", status];
}

-(NSString *) getpieceId{
    return artistId;
}

-(float) getValue{
    return value;
}

-(void) changeStatus :(char)stat{
    status = stat;
}

-(NSString *) getCuratorId{
    return curatorId;
}

-(void)setEstimate:(float)esti{
    estimate = esti;
}

@end
