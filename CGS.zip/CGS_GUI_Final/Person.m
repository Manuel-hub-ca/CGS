//
//  Person.m
//  CGS
//
//  Created by Mac on 2022-10-05.
//

#import "Person.h"

@implementation Person
    
-(id) initFirstName:(NSString *)FN initLastName:(NSString *)LN{
    firstname = FN;
    lastname = LN;
    return self;
}

-(NSString *) toString{
    return  [NSString stringWithFormat:(@"%@%@%@"), firstname,@" ", lastname];

 }

-(NSString *) getfirstname{
    return firstname;
}
-(void) setfirstName:(NSString *) fn{
    firstname = fn;
}

-(NSString *) getlasttname{
    return lastname;
}
-(void) setlastName:(NSString *) ln{
    lastname = ln;
}


@end
