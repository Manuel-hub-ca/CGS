//
//  Curator.m
//  CGS
//
//  Created by Mac on 2022-10-05.
//

#import "Curator.h"

@implementation Curator
-(id) initCuratorId:(NSString *)CId initFirstName:(NSString *)FN initLastName:(NSString *)LN initCommission:(float)Comm{
    curatorID = CId;
    firstname= FN;
    lastname = LN;
    commission = Comm;
    return self;
}


-(NSString *) getID{
    return curatorID;
}

-(NSString *) toString{
   return [NSString stringWithFormat:(@"\n%@%@\n %@%@ %@%@\n %@%.2f\n"), @"Curator Id: ",curatorID, @"Name: ", firstname, @" ", lastname, @"Commission: ",commission];
}

-(void)setCommission :(float)comm{
    commission += comm;
}

@end


