//
//  Curator.h
//  CGS
//
//  Created by Mac on 2022-10-05.
//

#import <Foundation/Foundation.h>
#import "Person.h"
NS_ASSUME_NONNULL_BEGIN

@interface Curator : Person{
    NSString *curatorID;
    float commission;
    
    
}
-(id) initCuratorId:(NSString *)CId initFirstName:(NSString *)FN initLastName:(NSString *)LN initCommission:(float)Comm;
-(NSString *) toString;
-(NSString *) getID;
-(void)setCommission:(float)comm;
@end

NS_ASSUME_NONNULL_END
